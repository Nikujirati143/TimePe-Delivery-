import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import Home from './pages/Home';
import Categories from './pages/Categories';
import Join from './pages/Join';
import Admin from './pages/Admin';

const App = () => {
  return (
    <Router>
      <nav className='p-4 flex gap-4 bg-blue-600 text-white'>
        <Link to='/'>Home</Link>
        <Link to='/categories'>Categories</Link>
        <Link to='/join'>Join</Link>
        <Link to='/admin'>Admin</Link>
      </nav>
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='/categories' element={<Categories />} />
        <Route path='/join' element={<Join />} />
        <Route path='/admin' element={<Admin />} />
      </Routes>
    </Router>
  );
};

export default App;