import React, { useEffect, useState } from 'react';
import { db } from '../firebase/config';
import { collection, getDocs } from 'firebase/firestore';

const Admin = () => {
  const [partners, setPartners] = useState([]);

  useEffect(() => {
    const fetchPartners = async () => {
      const querySnapshot = await getDocs(collection(db, 'partners'));
      const data = querySnapshot.docs.map((doc) => doc.data());
      setPartners(data);
    };
    fetchPartners();
  }, []);

  return (
    <div className='p-4'>
      <h2 className='text-xl font-bold mb-4'>Delivery Partners</h2>
      {partners.map((p, i) => (
        <div key={i} className='border p-2 mb-2 rounded'>
          <strong>{p.name}</strong> - {p.city} - {p.phone}
        </div>
      ))}
    </div>
  );
};

export default Admin;