import React, { useState } from 'react';
import { db } from '../firebase/config';
import { collection, addDoc } from 'firebase/firestore';

const Join = () => {
  const [form, setForm] = useState({ name: '', phone: '', city: '', kyc: '' });

  const handleSubmit = async (e) => {
    e.preventDefault();
    await addDoc(collection(db, 'partners'), form);
    alert('Registration Submitted!');
  };

  return (
    <form onSubmit={handleSubmit} className='p-4 space-y-4'>
      <input className='w-full border p-2' placeholder='Name' onChange={(e) => setForm({ ...form, name: e.target.value })} />
      <input className='w-full border p-2' placeholder='Phone' onChange={(e) => setForm({ ...form, phone: e.target.value })} />
      <input className='w-full border p-2' placeholder='City' onChange={(e) => setForm({ ...form, city: e.target.value })} />
      <input className='w-full border p-2' placeholder='KYC ID' onChange={(e) => setForm({ ...form, kyc: e.target.value })} />
      <button type='submit' className='bg-green-600 text-white py-2 px-4 rounded'>Join Now</button>
    </form>
  );
};

export default Join;