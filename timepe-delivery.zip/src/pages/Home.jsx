import React from 'react';

const Home = () => {
  return (
    <div className='p-4 text-center'>
      <h1 className='text-3xl font-bold'>🚚 TimePe Delivery</h1>
      <p className='text-gray-600 mt-2'>Fast Delivery Services Across Your City</p>
    </div>
  );
};

export default Home;