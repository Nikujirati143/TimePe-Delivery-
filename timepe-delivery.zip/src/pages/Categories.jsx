import React from 'react';

const categories = [
  { name: 'Food', image: '/assets/food.png' },
  { name: 'Medicine', image: '/assets/medicine.png' },
  { name: 'Courier', image: '/assets/courier.png' },
];

const Categories = () => {
  return (
    <div className='grid grid-cols-2 gap-4 p-4'>
      {categories.map((cat) => (
        <div key={cat.name} className='bg-white shadow p-3 rounded-xl text-center'>
          <img src={cat.image} alt={cat.name} className='mx-auto h-16' />
          <h3 className='mt-2 font-semibold'>{cat.name}</h3>
        </div>
      ))}
    </div>
  );
};

export default Categories;